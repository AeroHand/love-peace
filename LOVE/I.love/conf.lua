function love.conf(t)

--设置标题和窗口大小
t.title = "I"
t.author = "Aerohand" -- The author of the game (string)
t.url = nil -- The website of the game (string)
t.identity = nil -- The name of the save directory (string)
t.version = "0.9.0" -- The LÖVE version this game was made for (string)
t.console = false -- Attach a console (boolean, Windows only)
t.release = false -- Enable release mode (boolean)


end